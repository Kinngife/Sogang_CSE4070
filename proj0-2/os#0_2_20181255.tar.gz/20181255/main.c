#include "list.h"
#include "hash.h"
#include "bitmap.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	LIST *list = (LIST *)malloc(sizeof(LIST) * 10);
	HASH *hash = (HASH *)malloc(sizeof(HASH) * 10);
	BITMAP *bitmap = (BITMAP *)malloc(sizeof(BITMAP) * 10);
	char input[100];
	char **command = (char **)malloc(sizeof(char *) * 100);
	int flag = 1;
	while (flag)
	{
		fgets(input, 100, stdin);
		input[strlen(input) - 1] = '\0';
		char *str = strtok(input, " ");
		int idx = 0;
		while (str != NULL)
		{
			command[idx++] = str;
			str = strtok(NULL, " ");
		}

		// 0. 공통 함수
		// 1) quit
		if (!strcmp(command[0], "quit"))
		{
			flag = 0;
		}
		// 2) create
		else if (!strcmp(command[0], "create"))
		{
			if (!strcmp(command[1], "list"))
			{
				char *name = command[2];
				int list_idx = name[strlen(name) - 1] - '0';
				list_init(&list[list_idx]);
			}
			else if (!strcmp(command[1], "hashtable"))
			{
				char *name = command[2];
				int hash_idx = name[strlen(name) - 1] - '0';
				hash_init(&hash[hash_idx], hash_func, hash_cmp, NULL);
			}
			else if (!strcmp(command[1], "bitmap"))
			{
				char *name = command[2];
				int bitmap_idx = name[strlen(name) - 1] - '0';
				size_t size = atoi(command[3]);
				bitmap[bitmap_idx] = *bitmap_create(size);
			}
		}
		// 3) delete
		else if (!strcmp(command[0], "delete"))
		{
			char *name = command[1];
			if (name[0] == 'l')
			{
				int list_idx = name[strlen(name) - 1] - '0';
				list_destroy(&list[list_idx]);
			}
			else if (name[0] == 'h')
			{
				int hash_idx = name[strlen(name) - 1] - '0';
				hash_destroy(&hash[hash_idx], hash_destructor);
			}
			else if (name[0] == 'b')
			{
				int bitmap_idx = name[strlen(name) - 1] - '0';
				bitmap_destroy(&bitmap[bitmap_idx]);
			}
		}
		// 4) dumpdata
		else if (!strcmp(command[0], "dumpdata"))
		{
			char *name = command[1];
			if (name[0] == 'l')
			{
				int list_idx = name[strlen(name) - 1] - '0';
				if (list_empty(&list[list_idx]))
					continue;

				for (LIST_ELEM *cur = list_begin(&list[list_idx]); cur != list_end(&list[list_idx]); cur = list_next(cur))
				{
					LIST_ITEM *item = list_entry(cur, LIST_ITEM, elem);
					printf("%d ", item->data);
				}
				printf("\n");
			}
			else if (name[0] == 'h')
			{
				int hash_idx = name[strlen(name) - 1] - '0';
				if (hash_empty(&hash[hash_idx]))
					continue;

				HASH_ITER it;
				hash_first(&it, &hash[hash_idx]);
				while (hash_next(&it))
				{
					int data = hash_entry(hash_cur(&it), HASH_ITEM, elem)->data;
					printf("%d ", data);
				}
				printf("\n");
			}
			else if (name[0] == 'b')
			{
				int bitmap_idx = name[strlen(name) - 1] - '0';
				if ((int)(bitmap_size(&bitmap[bitmap_idx]) == 0))
					continue;

				for (int i = 0; i < bitmap_size(&bitmap[bitmap_idx]); i++)
				{
					if (bitmap_test(&bitmap[bitmap_idx], i))
						printf("1");
					else
						printf("0");
				}
				printf("\n");
			}
		}

		// 1. list 함수
		// 1) list_push_front, list_push_back
		else if (!strcmp(command[0], "list_push_front"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';
			int data = atoi(command[2]);

			LIST_ITEM *newitem = (LIST_ITEM *)malloc(sizeof(LIST_ITEM *));
			newitem->data = data;
			list_push_front(&list[list_idx], &(newitem->elem));
		}
		else if (!strcmp(command[0], "list_push_back"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';
			int data = atoi(command[2]);

			LIST_ITEM *newitem = malloc(sizeof(LIST_ITEM *));
			newitem->data = data;
			list_push_back(&list[list_idx], &(newitem->elem));
		}
		// 2) list_insert, list_insert_ordered
		else if (!strcmp(command[0], "list_insert"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';
			int insert_idx = atoi(command[2]);
			int data = atoi(command[3]);

			LIST_ITEM *newitem = (LIST_ITEM *)malloc(sizeof(LIST_ITEM *));
			newitem->data = data;

			LIST_ELEM *cur = list_begin(&list[list_idx]);
			for (int i = 0; i < insert_idx; i++)
				cur = list_next(cur);

			list_insert(cur, &(newitem->elem));
		}
		else if (!strcmp(command[0], "list_insert_ordered"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';
			int data = atoi(command[2]);

			LIST_ITEM *newitem = (LIST_ITEM *)malloc(sizeof(LIST_ITEM *));
			newitem->data = data;

			list_insert_ordered(&list[list_idx], &(newitem->elem), list_cmp, NULL);
		}
		// 3) list_splice
		else if (!strcmp(command[0], "list_splice"))
		{
			char *name1 = command[1];
			int insert_list_idx = name1[strlen(name1) - 1] - '0';
			int insert_idx = atoi(command[2]);
			char *name2 = command[3];
			int splice_list_idx = name2[strlen(name2) - 1] - '0';
			int splice_idx1 = atoi(command[4]);
			int splice_idx2 = atoi(command[5]);

			LIST_ELEM *A = list_begin(&list[insert_list_idx]);
			LIST_ELEM *B = list_begin(&list[splice_list_idx]);
			LIST_ELEM *C = list_begin(&list[splice_list_idx]);
			for (int i = 0; i < insert_idx; i++)
				A = list_next(A);
			for (int i = 0; i < splice_idx1; i++)
				B = list_next(B);
			for (int i = 0; i < splice_idx2; i++)
				C = list_next(C);

			list_splice(A, B, C);
		}
		// 4) list_pop_front, list_pop_back
		else if (!strcmp(command[0], "list_pop_front"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';

			list_pop_front(&list[list_idx]);
		}
		else if (!strcmp(command[0], "list_pop_back"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';

			list_pop_back(&list[list_idx]);
		}
		// 5) list_remove
		else if (!strcmp(command[0], "list_remove"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';
			int remove_idx = atoi(command[2]);

			LIST_ELEM *cur = list_begin(&list[list_idx]);
			for (int i = 0; i < remove_idx; i++)
				cur = list_next(cur);
			list_remove(cur);
		}
		// 6) list_front, list_back
		else if (!strcmp(command[0], "list_front"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';
			int data = list_entry(list_front(&list[list_idx]), LIST_ITEM, elem)->data;
			printf("%d\n", data);
		}
		else if (!strcmp(command[0], "list_back"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';
			int data = list_entry(list_back(&list[list_idx]), LIST_ITEM, elem)->data;
			printf("%d\n", data);
		}
		// 7) list_empty, list_size, list_max, list_min
		else if (!strcmp(command[0], "list_empty"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';

			if (list_empty(&list[list_idx]))
				printf("true\n");
			else
				printf("false\n");
		}
		else if (!strcmp(command[0], "list_size"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';

			printf("%zu\n", list_size(&list[list_idx]));
		}
		else if (!strcmp(command[0], "list_max"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';

			int data = list_entry(list_max(&list[list_idx], list_cmp, NULL), LIST_ITEM, elem)->data;
			printf("%d\n", data);
		}
		else if (!strcmp(command[0], "list_min"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';

			int data = list_entry(list_min(&list[list_idx], list_cmp, NULL), LIST_ITEM, elem)->data;
			printf("%d\n", data);
		}
		// 8) list_swap, list_shuffle, list_reverse, list_sort, list_unique
		else if (!strcmp(command[0], "list_swap"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';
			int a = atoi(command[2]), b = atoi(command[3]);

			LIST_ELEM *A = list_begin(&list[list_idx]);
			for (int i = 0; i < a; i++)
				A = list_next(A);
			LIST_ELEM *B = list_begin(&list[list_idx]);
			for (int i = 0; i < b; i++)
				B = list_next(B);

			if (a - b == 1)
				list_nearswap(B, A);
			else if (a - b == -1)
				list_nearswap(A, B);
			else
				list_swap(A, B);
		}
		else if (!strcmp(command[0], "list_shuffle"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';
			list_shuffle(&list[list_idx]);
		}
		else if (!strcmp(command[0], "list_reverse"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';

			list_reverse(&list[list_idx]);
		}
		else if (!strcmp(command[0], "list_sort"))
		{
			char *name = command[1];
			int list_idx = name[strlen(name) - 1] - '0';

			list_sort(&list[list_idx], list_cmp, NULL);
		}
		else if (!strcmp(command[0], "list_unique"))
		{
			char *name1 = command[1];
			int unique_list_idx = name1[strlen(name1) - 1] - '0';
			if (idx == 2)
				list_unique(&list[unique_list_idx], NULL, list_cmp, NULL);
			else
			{
				char *name2 = command[2];
				int dup_list_idx = name2[strlen(name2) - 1] - '0';
				list_unique(&list[unique_list_idx], &list[dup_list_idx], list_cmp, NULL);
			}
		}
		
		// 2. hash 함수
		// 1) hash_insert, hash_delete
		else if (!strcmp(command[0], "hash_insert"))
		{
			char *name = command[1];
			int hash_idx = name[strlen(name) - 1] - '0';
			int data = atoi(command[2]);

			HASH_ITEM *newitem = (HASH_ITEM *)malloc(sizeof(HASH_ITEM *));
			newitem->data = data;

			hash_insert(&hash[hash_idx], &(newitem->elem));
		}
		else if (!strcmp(command[0], "hash_delete"))
		{
			char *name = command[1];
			int hash_idx = name[strlen(name) - 1] - '0';
			int data = atoi(command[2]);

			HASH_ITEM *delitem = (HASH_ITEM *)malloc(sizeof(HASH_ITEM *));
			delitem->data = data;

			hash_delete(&hash[hash_idx], &(delitem->elem));
		}
		// 2) hash_empty
		else if (!strcmp(command[0], "hash_empty"))
		{
			char *name = command[1];
			int hash_idx = name[strlen(name) - 1] - '0';

			if (hash_empty(&hash[hash_idx]))
				printf("true\n");
			else
				printf("false\n");
		}
		// 3) hash_size
		else if (!strcmp(command[0], "hash_size"))
		{
			char *name = command[1];
			int hash_idx = name[strlen(name) - 1] - '0';

			printf("%zu\n", hash_size(&hash[hash_idx]));
		}
		// 4) hash_clear
		else if (!strcmp(command[0], "hash_clear"))
		{
			char *name = command[1];
			int hash_idx = name[strlen(name) - 1] - '0';

			hash_clear(&hash[hash_idx], hash_destructor);
		}
		// 5) hash_apply, hash_find, hash_replace
		else if (!strcmp(command[0], "hash_apply"))
		{
			char *name1 = command[1];
			int hash_idx = name1[strlen(name1) - 1] - '0';
			char *name2 = command[2];
			if (!strcmp(name2, "square"))
				hash_apply(&hash[hash_idx], hash_square);
			else if (!strcmp(name2, "triple"))
				hash_apply(&hash[hash_idx], hash_triple);
		}
		else if (!strcmp(command[0], "hash_find"))
		{
			char *name = command[1];
			int hash_idx = name[strlen(name) - 1] - '0';
			int data = atoi(command[2]);

			HASH_ITEM *finditem = (HASH_ITEM *)malloc(sizeof(HASH_ITEM *));
			finditem->data = data;

			if (hash_find(&hash[hash_idx], &(finditem->elem)) == NULL)
				continue;
			int finddata = hash_entry(hash_find(&hash[hash_idx], &(finditem->elem)), HASH_ITEM, elem)->data;
			printf("%d\n", finddata);
		}
		else if (!strcmp(command[0], "hash_replace"))
		{
			char *name = command[1];
			int hash_idx = name[strlen(name) - 1] - '0';
			int data = atoi(command[2]);

			HASH_ITEM *replaceitem = (HASH_ITEM *)malloc(sizeof(HASH_ITEM *));
			replaceitem->data = data;

			hash_replace(&hash[hash_idx], &(replaceitem->elem));
		}

		// 3. bitmap 함수
		// 1) bitmap_test
		else if (!strcmp(command[0], "bitmap_test"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int index = atoi(command[2]);

			if (bitmap_test(&bitmap[bitmap_idx], index))
				printf("true\n");
			else
				printf("false\n");
		}
		// 2) bitmap_mark
		else if (!strcmp(command[0], "bitmap_mark"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int index = atoi(command[2]);

			bitmap_mark(&bitmap[bitmap_idx], index);
		}
		// 3) bitmap_contains
		else if (!strcmp(command[0], "bitmap_contains"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int start = atoi(command[2]);
			int cnt = atoi(command[3]);

			if (!strcmp(command[4], "true"))
			{
				if (bitmap_contains(&bitmap[bitmap_idx], start, cnt, true))
					printf("true\n");
				else
					printf("false\n");
			}
			else if (!strcmp(command[4], "false"))
			{
				if (bitmap_contains(&bitmap[bitmap_idx], start, cnt, false))
					printf("true\n");
				else
					printf("false\n");
			}
		}
		// 4) bitmap_all, bitmap_any, bitmap_none, bitmap_count
		else if (!strcmp(command[0], "bitmap_all"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int start = atoi(command[2]);
			int cnt = atoi(command[3]);

			if (bitmap_all(&bitmap[bitmap_idx], start, cnt))
				printf("true\n");
			else
				printf("false\n");
		}
		else if (!strcmp(command[0], "bitmap_any"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int start = atoi(command[2]);
			int cnt = atoi(command[3]);

			if (bitmap_any(&bitmap[bitmap_idx], start, cnt))
				printf("true\n");
			else
				printf("false\n");
		}
		else if (!strcmp(command[0], "bitmap_none"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int start = atoi(command[2]);
			int cnt = atoi(command[3]);

			if (bitmap_none(&bitmap[bitmap_idx], start, cnt))
				printf("true\n");
			else
				printf("false\n");
		}
		else if (!strcmp(command[0], "bitmap_count"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int start = atoi(command[2]);
			int cnt = atoi(command[3]);

			if (!strcmp(command[4], "true"))
				printf("%zu\n", bitmap_count(&bitmap[bitmap_idx], start, cnt, true));
			else if (!strcmp(command[4], "false"))
				printf("%zu\n", bitmap_count(&bitmap[bitmap_idx], start, cnt, false));
		}
		// 5) bitmap_dump
		else if (!strcmp(command[0], "bitmap_dump"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';

			bitmap_dump(&bitmap[bitmap_idx]);
		}
		// 6) bitmap_expand
		else if (!strcmp(command[0], "bitmap_expand"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int size = atoi(command[2]);

			bitmap_expand(&bitmap[bitmap_idx], size);
		}
		// 7) bitmap_set, bitmap_reset, bitmap_set_multiple, bitmap_set_all
		else if (!strcmp(command[0], "bitmap_set"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int index = atoi(command[2]);

			if (!strcmp(command[3], "true"))
				bitmap_set(&bitmap[bitmap_idx], index, true);
			else
				bitmap_set(&bitmap[bitmap_idx], index, false);
		}
		else if (!strcmp(command[0], "bitmap_reset"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int index = atoi(command[2]);

			bitmap_reset(&bitmap[bitmap_idx], index);
		}
		else if (!strcmp(command[0], "bitmap_set_multiple"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int start = atoi(command[2]);
			int cnt = atoi(command[3]);

			if (!strcmp(command[4], "true"))
				bitmap_set_multiple(&bitmap[bitmap_idx], start, cnt, true);
			else if (!strcmp(command[4], "false"))
				bitmap_set_multiple(&bitmap[bitmap_idx], start, cnt, false);
		}
		else if (!strcmp(command[0], "bitmap_set_all"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';

			if (!strcmp(command[2], "true"))
				bitmap_set_all(&bitmap[bitmap_idx], true);
			else if (!strcmp(command[2], "false"))
				bitmap_set_all(&bitmap[bitmap_idx], false);
		}
		//8) bitmap_scan, bitmap_flip, bitmap_scan_and_flip
		else if (!strcmp(command[0], "bitmap_scan"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int start = atoi(command[2]);
			int cnt = atoi(command[3]);

			if (!strcmp(command[4], "true"))
				printf("%zu\n", bitmap_scan(&bitmap[bitmap_idx], start, cnt, true));
			else if (!strcmp(command[4], "false"))
				printf("%zu\n", bitmap_scan(&bitmap[bitmap_idx], start, cnt, false));
		}
		else if (!strcmp(command[0], "bitmap_flip"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int index = atoi(command[2]);

			bitmap_flip(&bitmap[bitmap_idx], index);
		}
		else if (!strcmp(command[0], "bitmap_scan_and_flip"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';
			int start = atoi(command[2]);
			int cnt = atoi(command[3]);

			if (!strcmp(command[4], "true"))
				printf("%zu\n", bitmap_scan_and_flip(&bitmap[bitmap_idx], start, cnt, true));
			else if (!strcmp(command[4], "false"))
				printf("%zu\n", bitmap_scan_and_flip(&bitmap[bitmap_idx], start, cnt, false));
		}
		// 9) bitmap_size
		else if (!strcmp(command[0], "bitmap_size"))
		{
			char *name = command[1];
			int bitmap_idx = name[strlen(name) - 1] - '0';

			printf("%zu\n", bitmap_size(&bitmap[bitmap_idx]));
		}
	}
}